import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { getNextProject, getProject } from "@/data/site";

export const Route = createFileRoute("/projetos/$slug")({
  loader: ({ params }) => {
    const project = getProject(params.slug);
    if (!project) throw notFound();
    return { project, next: getNextProject(params.slug) };
  },
  component: ProjectPage,
});

function ProjectPage() {
  const { project, next } = Route.useLoaderData();

  return (
    <SiteShell>
      <article className="px-5 pb-24 pt-28 sm:px-8 lg:px-12 lg:pt-36">
        <div className="mx-auto max-w-[92rem]">
          <Link
            to="/"
            hash="projetos"
            className="meta text-mute link-underline"
          >
            Índice
          </Link>

          <header className="mt-8 grid gap-8 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-8">
              <p className="meta text-mute">
                {project.year} — {project.category}
              </p>
              <h1 className="mt-4 font-display text-display">{project.name}</h1>
            </div>
            <p className="max-w-md font-display text-lead italic text-ink/80 lg:col-span-4">
              {project.summary}
            </p>
          </header>

          <div className="img-frame mt-12 aspect-[16/9] w-full">
            <img
              src={project.image}
              alt={`Imagem principal do projeto fictício ${project.name}`}
              width={project.imageWidth}
              height={project.imageHeight}
            />
          </div>

          <div className="mt-16 grid gap-12 lg:grid-cols-12">
            <p className="text-lg leading-relaxed text-ink/85 lg:col-span-7">
              {project.story}
            </p>
            <aside className="space-y-8 lg:col-span-4 lg:col-start-9">
              <div>
                <p className="meta text-ember">Desafio</p>
                <p className="mt-3 text-sm leading-relaxed text-mute">
                  {project.challenge}
                </p>
              </div>
              <div>
                <p className="meta text-ember">Solução</p>
                <p className="mt-3 text-sm leading-relaxed text-mute">
                  {project.solution}
                </p>
              </div>
              <div>
                <p className="meta text-ember">Resultado</p>
                <p className="mt-3 text-sm leading-relaxed text-mute">
                  {project.result}
                </p>
              </div>
            </aside>
          </div>

          <p className="mt-16 max-w-xl text-sm italic text-faint">
            Ensaio fictício para o modelo demonstrativo da NexaWeb. Não descreve
            um cliente, marca ou resultado real.
          </p>

          {next ? (
            <Link
              to="/projetos/$slug"
              params={{ slug: next.slug }}
              className="group mt-20 block border-t border-line pt-10"
            >
              <p className="meta text-mute">Próximo ensaio</p>
              <div className="mt-6 grid items-center gap-8 md:grid-cols-12">
                <div className="img-frame aspect-[16/10] md:col-span-5">
                  <img
                    src={next.image}
                    alt=""
                    width={next.imageWidth}
                    height={next.imageHeight}
                    loading="lazy"
                  />
                </div>
                <div className="md:col-span-7">
                  <h2 className="font-display text-section italic">{next.name}</h2>
                  <p className="mt-2 text-mute">{next.category}</p>
                </div>
              </div>
            </Link>
          ) : null}
        </div>
      </article>
    </SiteShell>
  );
}
