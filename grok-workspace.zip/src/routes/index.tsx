import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Hero } from "@/components/hero";
import { ProjectsIndex } from "@/components/projects-index";
import { FeaturedProject } from "@/components/featured-project";
import { About } from "@/components/about";
import { Experience } from "@/components/experience";
import { Specialties } from "@/components/specialties";
import { Contact } from "@/components/contact";
import { Faq } from "@/components/faq";
import { scrollToId } from "@/components/hash";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (!hash) return;
    const t = window.setTimeout(() => scrollToId(hash), 80);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <SiteShell>
      <Hero />
      <ProjectsIndex />
      <FeaturedProject />
      <About />
      <Experience />
      <Specialties />
      <Contact />
      <Faq />
    </SiteShell>
  );
}
