import { SPECIALTIES } from "@/data/site";

export function Specialties() {
  return (
    <section className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
      <div className="mx-auto max-w-[92rem]">
        <p className="meta text-mute">Ofício</p>
        <h2 className="mt-3 font-display text-section italic">Especialidades</h2>

        <ul className="mt-12">
          {SPECIALTIES.map((item, i) => (
            <li
              key={item.name}
              className="group grid grid-cols-12 items-baseline gap-4 border-t border-line py-6 last:border-b sm:py-8"
            >
              <span className="meta col-span-2 text-faint sm:col-span-1">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="col-span-10 font-display text-3xl tracking-tight transition-colors duration-300 group-hover:text-ember sm:col-span-5 sm:text-5xl">
                {item.name}
              </h3>
              <p className="col-span-12 max-w-md text-sm leading-relaxed text-mute sm:col-span-6 sm:col-start-7">
                {item.text}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
