import { Link } from "@tanstack/react-router";

export function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center bg-paper px-6 text-center text-ink">
      <p className="meta text-mute">Página ausente</p>
      <h1 className="font-display mt-4 text-section italic">Fora do recorte.</h1>
      <p className="mt-4 max-w-md text-mute">
        Este endereço não existe neste portfólio demonstrativo.
      </p>
      <Link
        to="/"
        className="btn-ink mt-10"
      >
        Voltar ao início
      </Link>
    </main>
  );
}
