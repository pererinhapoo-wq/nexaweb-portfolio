import { SITE } from "@/data/site";
import { scrollToId } from "@/components/hash";

export function Hero() {
  return (
    <section
      id="inicio"
      className="relative overflow-x-clip px-5 pb-16 pt-28 sm:px-8 sm:pb-24 sm:pt-32 lg:px-12 lg:pb-28 lg:pt-36"
    >
      <div className="mx-auto grid max-w-[92rem] items-end gap-10 lg:grid-cols-12 lg:gap-8">
        <div className="stagger-in lg:col-span-8">
          <p className="meta text-mute">{SITE.location}</p>
          <h1 className="mt-6 font-display text-display text-ink">
            <span className="block italic">Rafael</span>
            <span className="block -mt-[0.08em]">Monteiro</span>
          </h1>
          <p className="mt-6 text-lg text-mute sm:text-xl">{SITE.role}</p>
        </div>

        <div className="relative lg:col-span-4">
          <div className="img-frame aspect-[3/4] w-full max-w-md lg:ml-auto lg:max-w-none lg:-translate-y-6">
            <img
              src="/images/portrait.jpg"
              alt="Retrato ilustrativo de Rafael Monteiro, personagem fictício deste portfólio demonstrativo"
              width={1152}
              height={1728}
              fetchPriority="high"
            />
          </div>
          <p className="mt-3 meta text-faint">Retrato — demonstração</p>
        </div>
      </div>

      <div className="mx-auto mt-12 grid max-w-[92rem] gap-10 lg:grid-cols-12 lg:items-end">
        <div className="lg:col-span-7">
          <p className="font-display text-lead italic text-ink">
            “{SITE.tagline}”
          </p>
          <p className="mt-5 max-w-xl text-mute">{SITE.intro}</p>
        </div>
        <div className="flex items-end gap-4 lg:col-span-5 lg:justify-end">
          <button
            type="button"
            onClick={() => scrollToId("projetos")}
            className="group flex items-center gap-4 text-left"
          >
            <span className="relative flex h-16 w-px items-start overflow-hidden bg-line">
              <span className="scroll-line block h-full w-px bg-ember" />
            </span>
            <span>
              <span className="meta block text-mute">Índice</span>
              <span className="mt-1 block font-display text-2xl italic tracking-tight">
                Explorar o portfólio
              </span>
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}
