import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { NAV } from "@/data/site";
import { scrollToId } from "@/components/hash";
import { cn } from "@/lib/utils";

export function SiteNav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const onHome = location.pathname === "/";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  function go(id: string) {
    setOpen(false);
    document.body.style.overflow = "";
    if (onHome) {
      window.history.replaceState(null, "", `/#${id}`);
      window.setTimeout(() => scrollToId(id), 60);
      return;
    }
    void navigate({ to: "/", hash: id });
  }

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-40 transition-[background-color,border-color] duration-300",
          scrolled || open
            ? "border-b border-line bg-paper/90 backdrop-blur-md"
            : "border-b border-transparent bg-transparent",
        )}
      >
        <div className="mx-auto flex h-16 max-w-[92rem] items-center justify-between gap-4 px-5 sm:h-[4.5rem] sm:px-8 lg:px-12">
          <Link
            to="/"
            className="font-display text-xl tracking-tight italic sm:text-2xl"
            onClick={() => setOpen(false)}
          >
            RM
          </Link>

          <nav className="hidden items-center gap-8 lg:flex" aria-label="Principal">
            {NAV.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                className="meta text-mute transition-colors duration-200 hover:text-ink"
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => go("contato")}
              className="meta hidden text-ink link-underline sm:inline-flex"
            >
              Vamos conversar
            </button>
            <button
              type="button"
              className="meta inline-flex min-h-11 items-center text-ink lg:hidden"
              aria-expanded={open}
              aria-controls="menu-overlay"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? "Fechar" : "Menu"}
            </button>
          </div>
        </div>
      </header>

      <div
        id="menu-overlay"
        aria-hidden={!open}
        inert={!open}
        className={cn(
          "fixed inset-0 z-30 flex flex-col justify-end bg-paper px-6 pb-10 pt-24 transition-[opacity,visibility] duration-300 lg:hidden",
          open
            ? "visible opacity-100 pointer-events-auto"
            : "invisible pointer-events-none opacity-0",
        )}
      >
        <nav className="flex flex-col" aria-label="Mobile">
          {NAV.map((item, i) => (
            <button
              key={item.id}
              type="button"
              onClick={() => go(item.id)}
              className="flex min-h-16 items-center justify-between border-t border-line text-left"
              style={{ transitionDelay: open ? `${i * 40}ms` : "0ms" }}
            >
              <span className="font-display text-4xl italic tracking-tight sm:text-5xl">
                {item.label}
              </span>
              <span className="meta text-faint">0{i + 1}</span>
            </button>
          ))}
          <button
            type="button"
            onClick={() => go("contato")}
            className="mt-8 self-start btn-ink"
          >
            Vamos conversar
          </button>
        </nav>
      </div>
    </>
  );
}
