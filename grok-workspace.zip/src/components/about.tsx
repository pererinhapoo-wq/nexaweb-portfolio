import { ABOUT } from "@/data/site";

export function About() {
  return (
    <section id="sobre" className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
      <div className="mx-auto grid max-w-[92rem] gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <p className="meta text-mute">Sobre</p>
          <h2 className="mt-3 font-display text-section italic">{ABOUT.title}</h2>
          <p className="mt-6 text-sm italic text-ember">{ABOUT.lead}</p>
          <div className="mt-8 space-y-5 text-lg leading-relaxed text-ink/85">
            {ABOUT.body.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
        </div>

        <div className="relative lg:col-span-7">
          <div className="grid grid-cols-12 gap-4">
            <div className="img-frame col-span-8 aspect-[2/3] sm:col-span-7">
              <img
                src={ABOUT.portrait}
                alt="Retrato profissional fictício de Rafael Monteiro"
                width={1152}
                height={1728}
                loading="lazy"
              />
            </div>
            <div className="col-span-4 flex flex-col justify-end sm:col-span-5">
              <div className="img-frame aspect-[3/2]">
                <img
                  src={ABOUT.atelier}
                  alt="Interior fictício do ateliê"
                  width={1728}
                  height={1152}
                  loading="lazy"
                />
              </div>
              <p className="mt-4 hidden max-w-[12rem] text-sm leading-relaxed text-mute sm:block">
                Luz de ateliê, papel e intervalo. Um espaço inventado para este
                modelo.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
