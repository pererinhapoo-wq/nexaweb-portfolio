import { useState, type FormEvent, type ReactNode } from "react";
import { PROJECT_TYPES, SITE } from "@/data/site";

type FormState = {
  name: string;
  email: string;
  company: string;
  type: string;
  message: string;
};

const empty: FormState = {
  name: "",
  email: "",
  company: "",
  type: "",
  message: "",
};

export function Contact() {
  const [form, setForm] = useState<FormState>(empty);
  const [errors, setErrors] = useState<Partial<FormState>>({});
  const [sent, setSent] = useState(false);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  function validate() {
    const next: Partial<FormState> = {};
    if (!form.name.trim()) next.name = "Escreva um nome.";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      next.email = "Informe um e-mail válido.";
    }
    if (!form.type) next.type = "Escolha um tipo de projeto.";
    if (!form.message.trim()) next.message = "Deixe uma mensagem.";
    return next;
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const next = validate();
    if (Object.keys(next).length) {
      setErrors(next);
      return;
    }
    setSent(true);
  }

  return (
    <section id="contato" className="bg-night text-cream">
      <div className="mx-auto grid max-w-[92rem] gap-14 px-5 py-20 sm:px-8 lg:grid-cols-12 lg:px-12 lg:py-28">
        <div className="lg:col-span-5">
          <p className="meta text-faint">Correspondência</p>
          <h2 className="mt-4 font-display text-section italic">Tem uma ideia?</h2>
          <p className="mt-6 max-w-md font-display text-lead italic text-cream/85">
            Vamos transformar sua próxima ideia em algo que merece ser visto.
          </p>
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-cream/55">
            Formulário de demonstração: o envio é apenas visual. Nenhuma mensagem
            é armazenada ou encaminhada.
          </p>

          <ul className="mt-12 space-y-4 text-sm">
            <li>
              <span className="meta block text-faint">E-mail</span>
              <a href={`mailto:${SITE.email}`} className="link-underline mt-1 inline-block">
                {SITE.email}
              </a>
            </li>
            <li>
              <span className="meta block text-faint">Instagram</span>
              <a
                href={SITE.instagramUrl}
                target="_blank"
                rel="noreferrer"
                className="link-underline mt-1 inline-block"
              >
                {SITE.instagram}
              </a>
            </li>
            <li>
              <span className="meta block text-faint">LinkedIn</span>
              <a
                href={SITE.linkedinUrl}
                target="_blank"
                rel="noreferrer"
                className="link-underline mt-1 inline-block"
              >
                {SITE.linkedin}
              </a>
            </li>
          </ul>
        </div>

        <div className="lg:col-span-6 lg:col-start-7">
          {sent ? (
            <div className="border-t border-night-line pt-8">
              <p className="font-display text-4xl italic">Recebido — no papel.</p>
              <p className="mt-4 max-w-md text-cream/70">
                Obrigado. Esta confirmação é apenas uma simulação para o modelo
                demonstrativo da NexaWeb. Nada foi enviado.
              </p>
              <button
                type="button"
                className="btn-cream mt-10"
                onClick={() => {
                  setSent(false);
                  setForm(empty);
                }}
              >
                Escrever outra mensagem
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-2">
              <Field
                label="Nome"
                error={errors.name}
              >
                <input
                  className="field field-night"
                  value={form.name}
                  onChange={(e) => update("name", e.target.value)}
                  autoComplete="name"
                />
              </Field>
              <Field label="E-mail" error={errors.email}>
                <input
                  className="field field-night"
                  type="email"
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                  autoComplete="email"
                />
              </Field>
              <Field label="Empresa" error={errors.company}>
                <input
                  className="field field-night"
                  value={form.company}
                  onChange={(e) => update("company", e.target.value)}
                  autoComplete="organization"
                />
              </Field>
              <Field label="Tipo de projeto" error={errors.type}>
                <select
                  className="field field-night"
                  value={form.type}
                  onChange={(e) => update("type", e.target.value)}
                >
                  <option value="">Selecionar</option>
                  {PROJECT_TYPES.map((t) => (
                    <option key={t} value={t} className="text-ink">
                      {t}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Mensagem" error={errors.message}>
                <textarea
                  className="field field-night"
                  value={form.message}
                  onChange={(e) => update("message", e.target.value)}
                />
              </Field>
              <div className="pt-8">
                <button type="submit" className="btn-cream">
                  Enviar projeto
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <label className="block pt-4">
      <span className="meta text-faint">{label}</span>
      {children}
      {error ? (
        <span className="mt-2 block text-sm text-ember-soft">{error}</span>
      ) : null}
    </label>
  );
}
