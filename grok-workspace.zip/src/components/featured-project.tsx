import { Link } from "@tanstack/react-router";
import { FEATURED, getProject } from "@/data/site";

export function FeaturedProject() {
  const orbit = getProject("orbit");

  return (
    <section className="bg-night text-cream">
      <div className="mx-auto max-w-[92rem] px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <p className="meta text-faint">{FEATURED.title}</p>
        <h2 className="mt-4 max-w-4xl font-display text-section italic">
          {FEATURED.headline}
        </h2>

        <div className="img-frame mt-12 aspect-[16/9] w-full">
          <img
            src={FEATURED.image}
            alt="Instalação conceitual do projeto fictício ORBIT"
            width={FEATURED.imageWidth}
            height={FEATURED.imageHeight}
            loading="lazy"
          />
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-12">
          <p className="font-display text-lead italic text-cream/90 lg:col-span-5">
            {FEATURED.description}
          </p>
          <div className="grid gap-8 sm:grid-cols-3 lg:col-span-7">
            <div>
              <p className="meta text-ember-soft">Desafio</p>
              <p className="mt-3 text-sm leading-relaxed text-cream/70">
                {orbit?.challenge}
              </p>
            </div>
            <div>
              <p className="meta text-ember-soft">Solução</p>
              <p className="mt-3 text-sm leading-relaxed text-cream/70">
                {orbit?.solution}
              </p>
            </div>
            <div>
              <p className="meta text-ember-soft">Resultado</p>
              <p className="mt-3 text-sm leading-relaxed text-cream/70">
                {orbit?.result}
              </p>
            </div>
          </div>
        </div>

        <Link
          to="/projetos/$slug"
          params={{ slug: "orbit" }}
          className="mt-12 inline-flex min-h-11 items-center border-b border-cream/40 pb-1 text-sm tracking-wide transition-colors duration-200 hover:border-ember hover:text-ember-soft"
        >
          Ler o ensaio completo
        </Link>
      </div>
    </section>
  );
}
