import { Link } from "@tanstack/react-router";
import { PROJECTS } from "@/data/site";
import { cn } from "@/lib/utils";

const layoutClass: Record<string, string> = {
  orbit: "md:col-span-7 md:row-span-2",
  nord: "md:col-span-5",
  mono: "md:col-span-4 md:row-span-2",
  vela: "md:col-span-8",
  aura: "md:col-span-8",
  frame: "md:col-span-12",
};

export function ProjectsIndex() {
  return (
    <section id="projetos" className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
      <div className="mx-auto max-w-[92rem]">
        <div className="mb-12 flex flex-col gap-4 border-t border-line pt-8 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="meta text-mute">Seleção</p>
            <h2 className="mt-3 font-display text-section italic">Projetos</h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-mute">
            Seis ensaios fictícios. Composição editorial — não um mosaico de
            cartões. Cada peça é um ponto de vista.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-10 md:grid-cols-12 md:gap-x-6 md:gap-y-16">
          {PROJECTS.map((project, i) => (
            <Link
              key={project.slug}
              to="/projetos/$slug"
              params={{ slug: project.slug }}
              className={cn(
                "group block min-w-0",
                layoutClass[project.slug] ?? "md:col-span-6",
              )}
            >
              <article>
                <div
                  className={cn(
                    "img-frame",
                    project.layout === "tall"
                      ? "aspect-[3/4]"
                      : project.slug === "frame"
                        ? "aspect-[16/8]"
                        : project.slug === "orbit"
                          ? "aspect-[4/5] sm:aspect-[4/3] md:aspect-[4/5]"
                          : "aspect-[16/10]",
                  )}
                >
                  <img
                    src={project.image}
                    alt={`Imagem do projeto fictício ${project.name}`}
                    width={project.imageWidth}
                    height={project.imageHeight}
                    loading="lazy"
                  />
                </div>
                <div className="mt-4 flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <p className="meta text-faint">
                      {String(i + 1).padStart(2, "0")} — {project.year}
                    </p>
                    <h3 className="mt-1 font-display text-3xl tracking-tight sm:text-4xl">
                      <span className="link-underline">{project.name}</span>
                    </h3>
                    <p className="mt-1 text-sm text-mute">{project.category}</p>
                    <p className="mt-3 max-w-md text-sm leading-relaxed text-mute">
                      {project.summary}
                    </p>
                  </div>
                  <span className="meta mt-2 shrink-0 text-ember opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                    Ver
                  </span>
                </div>
              </article>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
