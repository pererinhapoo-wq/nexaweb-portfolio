import { useState } from "react";
import { FAQ } from "@/data/site";
import { cn } from "@/lib/utils";

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
      <div className="mx-auto grid max-w-[92rem] gap-12 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <p className="meta text-mute">Dúvidas</p>
          <h2 className="mt-3 font-display text-section italic">Perguntas</h2>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-mute">
            Respostas ilustrativas. Este portfólio é um modelo demonstrativo —
            não representa um ateliê real.
          </p>
        </div>
        <ul className="lg:col-span-8">
          {FAQ.map((item, i) => {
            const isOpen = open === i;
            return (
              <li key={item.q} className="border-t border-line last:border-b">
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full min-h-16 items-start justify-between gap-6 py-6 text-left"
                >
                  <span className="min-w-0 font-display text-2xl tracking-tight sm:text-3xl">
                    {item.q}
                  </span>
                  <span
                    className={cn(
                      "mt-2 inline-block h-4 w-4 shrink-0 transition-transform duration-300",
                      isOpen && "rotate-45",
                    )}
                    aria-hidden="true"
                  >
                    <svg viewBox="0 0 16 16" className="h-4 w-4 stroke-ink" fill="none">
                      <path d="M8 1v14M1 8h14" strokeWidth="1.2" />
                    </svg>
                  </span>
                </button>
                <div
                  className={cn(
                    "grid transition-[grid-template-rows,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                  )}
                >
                  <p className="overflow-hidden pb-6 text-mute">{item.a}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
