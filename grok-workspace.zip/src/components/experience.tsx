import { EXPERIENCE } from "@/data/site";

export function Experience() {
  return (
    <section
      id="experiencia"
      className="border-y border-line bg-cream px-5 py-20 sm:px-8 lg:px-12 lg:py-28"
    >
      <div className="mx-auto max-w-[92rem]">
        <div className="mb-14 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="meta text-mute">Linha do tempo</p>
            <h2 className="mt-3 font-display text-section italic">Experiência</h2>
          </div>
          <p className="max-w-sm text-sm italic text-mute">
            Percurso fictício, criado apenas para esta demonstração da NexaWeb.
          </p>
        </div>

        <ol className="relative">
          <span
            aria-hidden="true"
            className="absolute left-[4.5rem] top-0 hidden h-full w-px bg-line sm:left-[7.5rem] md:block"
          />
          {EXPERIENCE.map((item, i) => (
            <li
              key={item.year}
              className="relative grid gap-3 border-t border-line py-10 md:grid-cols-12 md:items-baseline md:gap-8"
            >
              <span className="font-display text-5xl tracking-tight text-ink/15 md:col-span-3 md:text-7xl">
                {item.year}
              </span>
              <div className="md:col-span-8 md:col-start-5">
                <p className="meta text-ember">0{i + 1}</p>
                <h3 className="mt-2 font-display text-3xl tracking-tight sm:text-4xl">
                  {item.title}
                </h3>
                <p className="mt-3 max-w-lg text-mute">{item.text}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
