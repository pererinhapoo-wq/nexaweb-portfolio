import type { ReactNode } from "react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-dvh overflow-x-clip bg-paper text-ink">
      <a
        href="#conteudo"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-ink focus:px-4 focus:py-2 focus:text-cream"
      >
        Ir ao conteúdo
      </a>
      <SiteNav />
      <main id="conteudo">{children}</main>
      <SiteFooter />
    </div>
  );
}
