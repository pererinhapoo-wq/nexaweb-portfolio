import { SITE } from "@/data/site";

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-paper">
      <div className="mx-auto flex max-w-[92rem] flex-col gap-10 px-5 py-14 sm:px-8 lg:flex-row lg:items-end lg:justify-between lg:px-12 lg:py-20">
        <div>
          <p className="font-display text-4xl tracking-tight italic sm:text-6xl">
            {SITE.name}
          </p>
          <p className="mt-3 text-mute">{SITE.role}</p>
        </div>
        <div className="max-w-sm text-sm leading-relaxed text-mute">
          <p>© 2026 — Projeto demonstrativo criado pela NexaWeb.</p>
          <p className="mt-2 italic">{SITE.demoNote}</p>
        </div>
      </div>
    </footer>
  );
}
