import { C as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./_ssr/router-BQqK56pO.mjs";
import { t as SiteShell } from "./_ssr/site-shell-OXHThy4a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-B7RvE15N.js
var import_jsx_runtime = require_jsx_runtime();
function ProjectPage() {
	const { project, next } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "px-5 pb-24 pt-28 sm:px-8 lg:px-12 lg:pt-36",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[92rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					hash: "projetos",
					className: "meta text-mute link-underline",
					children: "Índice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mt-8 grid gap-8 lg:grid-cols-12 lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "meta text-mute",
							children: [
								project.year,
								" — ",
								project.category
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-display",
							children: project.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md font-display text-lead italic text-ink/80 lg:col-span-4",
						children: project.summary
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "img-frame mt-12 aspect-[16/9] w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: project.image,
						alt: `Imagem principal do projeto fictício ${project.name}`,
						width: project.imageWidth,
						height: project.imageHeight
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 grid gap-12 lg:grid-cols-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg leading-relaxed text-ink/85 lg:col-span-7",
						children: project.story
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "space-y-8 lg:col-span-4 lg:col-start-9",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "meta text-ember",
								children: "Desafio"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-mute",
								children: project.challenge
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "meta text-ember",
								children: "Solução"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-mute",
								children: project.solution
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "meta text-ember",
								children: "Resultado"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-mute",
								children: project.result
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-16 max-w-xl text-sm italic text-faint",
					children: "Ensaio fictício para o modelo demonstrativo da NexaWeb. Não descreve um cliente, marca ou resultado real."
				}),
				next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/projetos/$slug",
					params: { slug: next.slug },
					className: "group mt-20 block border-t border-line pt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta text-mute",
						children: "Próximo ensaio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid items-center gap-8 md:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "img-frame aspect-[16/10] md:col-span-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: next.image,
								alt: "",
								width: next.imageWidth,
								height: next.imageHeight,
								loading: "lazy"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-7",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-section italic",
								children: next.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-mute",
								children: next.category
							})]
						})]
					})]
				}) : null
			]
		})
	}) });
}
//#endregion
export { ProjectPage as component };
