//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BfL8F37c.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/projetos/$slug"],
		preloads: [
			"/assets/index-CRsyJslw.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/site-CaAn0_-z.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CRsyJslw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Di-hM6VW.js", "/assets/site-shell-wuEWN9Z5.js"]
	},
	"/projetos/$slug": {
		filePath: "/workspace/src/routes/projetos/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-sEo_m7rV.js", "/assets/site-shell-wuEWN9Z5.js"]
	}
} });
//#endregion
export { tsrStartManifest };
