import { i as __toESM } from "../_runtime.mjs";
import { c as SITE, d as getProject, i as FEATURED, l as SPECIALTIES, n as EXPERIENCE, o as PROJECTS, r as FAQ, s as PROJECT_TYPES, t as ABOUT } from "./site-vRvvv435.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn, r as scrollToId, t as SiteShell } from "./site-shell-OXHThy4a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CKBudgEF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "inicio",
		className: "relative overflow-x-clip px-5 pb-16 pt-28 sm:px-8 sm:pb-24 sm:pt-32 lg:px-12 lg:pb-28 lg:pt-36",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-[92rem] items-end gap-10 lg:grid-cols-12 lg:gap-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in lg:col-span-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta text-mute",
						children: SITE.location
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-6 font-display text-display text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block italic",
							children: "Rafael"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block -mt-[0.08em]",
							children: "Monteiro"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-lg text-mute sm:text-xl",
						children: SITE.role
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative lg:col-span-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "img-frame aspect-[3/4] w-full max-w-md lg:ml-auto lg:max-w-none lg:-translate-y-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/portrait.jpg",
						alt: "Retrato ilustrativo de Rafael Monteiro, personagem fictício deste portfólio demonstrativo",
						width: 1152,
						height: 1728,
						fetchPriority: "high"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 meta text-faint",
					children: "Retrato — demonstração"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-12 grid max-w-[92rem] gap-10 lg:grid-cols-12 lg:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-lead italic text-ink",
					children: [
						"“",
						SITE.tagline,
						"”"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-xl text-mute",
					children: SITE.intro
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-end gap-4 lg:col-span-5 lg:justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => scrollToId("projetos"),
					className: "group flex items-center gap-4 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "relative flex h-16 w-px items-start overflow-hidden bg-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "scroll-line block h-full w-px bg-ember" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "meta block text-mute",
						children: "Índice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-2xl italic tracking-tight",
						children: "Explorar o portfólio"
					})] })]
				})
			})]
		})]
	});
}
var layoutClass = {
	orbit: "md:col-span-7 md:row-span-2",
	nord: "md:col-span-5",
	mono: "md:col-span-4 md:row-span-2",
	vela: "md:col-span-8",
	aura: "md:col-span-8",
	frame: "md:col-span-12"
};
function ProjectsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "projetos",
		className: "px-5 py-20 sm:px-8 lg:px-12 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[92rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-12 flex flex-col gap-4 border-t border-line pt-8 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta text-mute",
					children: "Seleção"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-section italic",
					children: "Projetos"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm leading-relaxed text-mute",
					children: "Seis ensaios fictícios. Composição editorial — não um mosaico de cartões. Cada peça é um ponto de vista."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-10 md:grid-cols-12 md:gap-x-6 md:gap-y-16",
				children: PROJECTS.map((project, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/projetos/$slug",
					params: { slug: project.slug },
					className: cn("group block min-w-0", layoutClass[project.slug] ?? "md:col-span-6"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("img-frame", project.layout === "tall" ? "aspect-[3/4]" : project.slug === "frame" ? "aspect-[16/8]" : project.slug === "orbit" ? "aspect-[4/5] sm:aspect-[4/3] md:aspect-[4/5]" : "aspect-[16/10]"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: project.image,
							alt: `Imagem do projeto fictício ${project.name}`,
							width: project.imageWidth,
							height: project.imageHeight,
							loading: "lazy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "meta text-faint",
									children: [
										String(i + 1).padStart(2, "0"),
										" — ",
										project.year
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 font-display text-3xl tracking-tight sm:text-4xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "link-underline",
										children: project.name
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-mute",
									children: project.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-md text-sm leading-relaxed text-mute",
									children: project.summary
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "meta mt-2 shrink-0 text-ember opacity-0 transition-opacity duration-300 group-hover:opacity-100",
							children: "Ver"
						})]
					})] })
				}, project.slug))
			})]
		})
	});
}
function FeaturedProject() {
	const orbit = getProject("orbit");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-night text-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[92rem] px-5 py-20 sm:px-8 lg:px-12 lg:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta text-faint",
					children: FEATURED.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-4xl font-display text-section italic",
					children: FEATURED.headline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "img-frame mt-12 aspect-[16/9] w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: FEATURED.image,
						alt: "Instalação conceitual do projeto fictício ORBIT",
						width: FEATURED.imageWidth,
						height: FEATURED.imageHeight,
						loading: "lazy"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 grid gap-10 lg:grid-cols-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lead italic text-cream/90 lg:col-span-5",
						children: FEATURED.description
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 sm:grid-cols-3 lg:col-span-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "meta text-ember-soft",
								children: "Desafio"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-cream/70",
								children: orbit?.challenge
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "meta text-ember-soft",
								children: "Solução"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-cream/70",
								children: orbit?.solution
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "meta text-ember-soft",
								children: "Resultado"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-cream/70",
								children: orbit?.result
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/projetos/$slug",
					params: { slug: "orbit" },
					className: "mt-12 inline-flex min-h-11 items-center border-b border-cream/40 pb-1 text-sm tracking-wide transition-colors duration-200 hover:border-ember hover:text-ember-soft",
					children: "Ler o ensaio completo"
				})
			]
		})
	});
}
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "sobre",
		className: "px-5 py-20 sm:px-8 lg:px-12 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-[92rem] gap-12 lg:grid-cols-12 lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta text-mute",
						children: "Sobre"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-section italic",
						children: ABOUT.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm italic text-ember",
						children: ABOUT.lead
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 space-y-5 text-lg leading-relaxed text-ink/85",
						children: ABOUT.body.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p }, p))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative lg:col-span-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-12 gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "img-frame col-span-8 aspect-[2/3] sm:col-span-7",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: ABOUT.portrait,
							alt: "Retrato profissional fictício de Rafael Monteiro",
							width: 1152,
							height: 1728,
							loading: "lazy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-4 flex flex-col justify-end sm:col-span-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "img-frame aspect-[3/2]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: ABOUT.atelier,
								alt: "Interior fictício do ateliê",
								width: 1728,
								height: 1152,
								loading: "lazy"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 hidden max-w-[12rem] text-sm leading-relaxed text-mute sm:block",
							children: "Luz de ateliê, papel e intervalo. Um espaço inventado para este modelo."
						})]
					})]
				})
			})]
		})
	});
}
function Experience() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "experiencia",
		className: "border-y border-line bg-cream px-5 py-20 sm:px-8 lg:px-12 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[92rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-14 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta text-mute",
					children: "Linha do tempo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-section italic",
					children: "Experiência"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm italic text-mute",
					children: "Percurso fictício, criado apenas para esta demonstração da NexaWeb."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					className: "absolute left-[4.5rem] top-0 hidden h-full w-px bg-line sm:left-[7.5rem] md:block"
				}), EXPERIENCE.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative grid gap-3 border-t border-line py-10 md:grid-cols-12 md:items-baseline md:gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-5xl tracking-tight text-ink/15 md:col-span-3 md:text-7xl",
						children: item.year
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-8 md:col-start-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "meta text-ember",
								children: ["0", i + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-3xl tracking-tight sm:text-4xl",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-lg text-mute",
								children: item.text
							})
						]
					})]
				}, item.year))]
			})]
		})
	});
}
function Specialties() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 py-20 sm:px-8 lg:px-12 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[92rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta text-mute",
					children: "Ofício"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-section italic",
					children: "Especialidades"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-12",
					children: SPECIALTIES.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "group grid grid-cols-12 items-baseline gap-4 border-t border-line py-6 last:border-b sm:py-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "meta col-span-2 text-faint sm:col-span-1",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "col-span-10 font-display text-3xl tracking-tight transition-colors duration-300 group-hover:text-ember sm:col-span-5 sm:text-5xl",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "col-span-12 max-w-md text-sm leading-relaxed text-mute sm:col-span-6 sm:col-start-7",
								children: item.text
							})
						]
					}, item.name))
				})
			]
		})
	});
}
var empty = {
	name: "",
	email: "",
	company: "",
	type: "",
	message: ""
};
function Contact() {
	const [form, setForm] = (0, import_react.useState)(empty);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [sent, setSent] = (0, import_react.useState)(false);
	function update(key, value) {
		setForm((prev) => ({
			...prev,
			[key]: value
		}));
		setErrors((prev) => ({
			...prev,
			[key]: void 0
		}));
	}
	function validate() {
		const next = {};
		if (!form.name.trim()) next.name = "Escreva um nome.";
		if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = "Informe um e-mail válido.";
		if (!form.type) next.type = "Escolha um tipo de projeto.";
		if (!form.message.trim()) next.message = "Deixe uma mensagem.";
		return next;
	}
	function onSubmit(e) {
		e.preventDefault();
		const next = validate();
		if (Object.keys(next).length) {
			setErrors(next);
			return;
		}
		setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contato",
		className: "bg-night text-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-[92rem] gap-14 px-5 py-20 sm:px-8 lg:grid-cols-12 lg:px-12 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta text-faint",
						children: "Correspondência"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-section italic",
						children: "Tem uma ideia?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-md font-display text-lead italic text-cream/85",
						children: "Vamos transformar sua próxima ideia em algo que merece ser visto."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-sm text-sm leading-relaxed text-cream/55",
						children: "Formulário de demonstração: o envio é apenas visual. Nenhuma mensagem é armazenada ou encaminhada."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-12 space-y-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "meta block text-faint",
								children: "E-mail"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${SITE.email}`,
								className: "link-underline mt-1 inline-block",
								children: SITE.email
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "meta block text-faint",
								children: "Instagram"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: SITE.instagramUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "link-underline mt-1 inline-block",
								children: SITE.instagram
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "meta block text-faint",
								children: "LinkedIn"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: SITE.linkedinUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "link-underline mt-1 inline-block",
								children: SITE.linkedin
							})] })
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-6 lg:col-start-7",
				children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-night-line pt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl italic",
							children: "Recebido — no papel."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-cream/70",
							children: "Obrigado. Esta confirmação é apenas uma simulação para o modelo demonstrativo da NexaWeb. Nada foi enviado."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-cream mt-10",
							onClick: () => {
								setSent(false);
								setForm(empty);
							},
							children: "Escrever outra mensagem"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					noValidate: true,
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nome",
							error: errors.name,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field field-night",
								value: form.name,
								onChange: (e) => update("name", e.target.value),
								autoComplete: "name"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "E-mail",
							error: errors.email,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field field-night",
								type: "email",
								value: form.email,
								onChange: (e) => update("email", e.target.value),
								autoComplete: "email"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Empresa",
							error: errors.company,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field field-night",
								value: form.company,
								onChange: (e) => update("company", e.target.value),
								autoComplete: "organization"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tipo de projeto",
							error: errors.type,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "field field-night",
								value: form.type,
								onChange: (e) => update("type", e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Selecionar"
								}), PROJECT_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: t,
									className: "text-ink",
									children: t
								}, t))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mensagem",
							error: errors.message,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field field-night",
								value: form.message,
								onChange: (e) => update("message", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn-cream",
								children: "Enviar projeto"
							})
						})
					]
				})
			})]
		})
	});
}
function Field({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "meta text-faint",
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-2 block text-sm text-ember-soft",
				children: error
			}) : null
		]
	});
}
function Faq() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 py-20 sm:px-8 lg:px-12 lg:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-[92rem] gap-12 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta text-mute",
						children: "Dúvidas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-section italic",
						children: "Perguntas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-sm text-sm leading-relaxed text-mute",
						children: "Respostas ilustrativas. Este portfólio é um modelo demonstrativo — não representa um ateliê real."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "lg:col-span-8",
				children: FAQ.map((item, i) => {
					const isOpen = open === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-line last:border-b",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-expanded": isOpen,
							onClick: () => setOpen(isOpen ? null : i),
							className: "flex w-full min-h-16 items-start justify-between gap-6 py-6 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 font-display text-2xl tracking-tight sm:text-3xl",
								children: item.q
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-2 inline-block h-4 w-4 shrink-0 transition-transform duration-300", isOpen && "rotate-45"),
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 16 16",
									className: "h-4 w-4 stroke-ink",
									fill: "none",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M8 1v14M1 8h14",
										strokeWidth: "1.2"
									})
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("grid transition-[grid-template-rows,opacity] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]", isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "overflow-hidden pb-6 text-mute",
								children: item.a
							})
						})]
					}, item.q);
				})
			})]
		})
	});
}
function Home() {
	(0, import_react.useEffect)(() => {
		const hash = window.location.hash.replace("#", "");
		if (!hash) return;
		const t = window.setTimeout(() => scrollToId(hash), 80);
		return () => window.clearTimeout(t);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsIndex, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedProject, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Experience, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Specialties, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
	] });
}
//#endregion
export { Home as component };
