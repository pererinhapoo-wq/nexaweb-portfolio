//#region node_modules/.nitro/vite/services/ssr/assets/site-vRvvv435.js
var SITE = {
	name: "Rafael Monteiro",
	role: "Designer & Diretor Criativo",
	location: "Atelier — São Paulo",
	tagline: "Eu transformo ideias em experiências visuais.",
	intro: "Crio identidades, experiências digitais e projetos visuais pensados para fazer marcas serem lembradas.",
	email: "estudo@rafaelmonteiro.demo",
	instagram: "@rafael.monteiro.atelier",
	instagramUrl: "https://instagram.com/rafael.monteiro.atelier",
	linkedin: "linkedin.com/in/rafael-monteiro-demo",
	linkedinUrl: "https://linkedin.com/in/rafael-monteiro-demo",
	demoNote: "Conteúdo fictício para demonstração. Este é um modelo de portfólio criado pela NexaWeb."
};
var NAV = [
	{
		id: "inicio",
		label: "Início"
	},
	{
		id: "projetos",
		label: "Projetos"
	},
	{
		id: "sobre",
		label: "Sobre"
	},
	{
		id: "experiencia",
		label: "Experiência"
	},
	{
		id: "contato",
		label: "Contato"
	}
];
var PROJECTS = [
	{
		slug: "orbit",
		name: "ORBIT",
		year: "2024",
		category: "Identidade visual e direção de arte",
		summary: "Um sistema visual que orbita entre ciência e desejo — círculos, metal e silêncio.",
		image: "/images/orbit.jpg",
		imageWidth: 1600,
		imageHeight: 1200,
		layout: "wide",
		challenge: "Criar uma identidade que parecesse precisa sem parecer fria — um universo próprio, não um logotipo isolado.",
		solution: "Um alfabeto de anéis, pesos e intervalos. Papel escuro, cobre e creme. Direção de arte pensada como instalação, não como aplicação.",
		result: "Resultado conceitual de demonstração: a marca passou a ser reconhecida pela geometria antes mesmo do nome. (Dado ilustrativo, sem métricas reais.)",
		story: "ORBIT nasceu como um exercício de contenção. Em vez de explicar o produto, o trabalho constrói um campo gravitacional: materiais, ritmo e luz. Cada peça — do brand book ao ambiente — gira em torno de um único gesto circular."
	},
	{
		slug: "nord",
		name: "NORD",
		year: "2024",
		category: "Branding e experiência digital",
		summary: "Silêncio, luz fria e uma identidade que respira como paisagem.",
		image: "/images/nord.jpg",
		imageWidth: 1792,
		imageHeight: 1008,
		layout: "wide",
		challenge: "Traduzir a calma de um território nórdico fictício em marca e em tela, sem cair no clichê do minimalismo genérico.",
		solution: "Tipografia estreita, intervalos longos, uma paleta de gelo e madeira. O digital se comporta como um saguão: lento, claro, sem pressa.",
		result: "Resultado conceitual de demonstração: a experiência digital passou a ser descrita como um lugar, não como um site. (Dado ilustrativo.)",
		story: "NORD é um estudo sobre pausa. A identidade quase desaparece para deixar o espaço aparecer. No digital, cada transição é um deslocamento de luz — como atravessar um pavilhão ao entardecer."
	},
	{
		slug: "mono",
		name: "MONO",
		year: "2023",
		category: "Direção criativa e campanha",
		summary: "Uma campanha em preto e branco sobre presença e ausência.",
		image: "/images/mono.jpg",
		imageWidth: 1200,
		imageHeight: 1600,
		layout: "tall",
		challenge: "Falar de uma coleção sem mostrar produto. O briefing pedia tensão, não catálogo.",
		solution: "Figura única, arquitetura brutalista, contraste extremo. A campanha se recusa à cor para obrigar o olhar a permanecer.",
		result: "Resultado conceitual de demonstração: a série se tornou a imagem mais citada da temporada fictícia. (Dado ilustrativo.)",
		story: "MONO é um ensaio visual. O corpo atravessa a colunata como um sinal. Não há slogan: o recorte, o grão e o silêncio fazem o trabalho da linguagem."
	},
	{
		slug: "vela",
		name: "VELA",
		year: "2023",
		category: "Identidade e embalagem",
		summary: "Embalagens que se comportam como objetos, não como invólucros.",
		image: "/images/vela.jpg",
		imageWidth: 1600,
		imageHeight: 1200,
		layout: "square",
		challenge: "Desenhar um universo sensorial para uma casa de fragrâncias fictícia, onde o objeto deveria merecer a mesa, não só a prateleira.",
		solution: "Cerâmica fosca, curva de vela, linho e sal. A identidade vive no toque tanto quanto no desenho.",
		result: "Resultado conceitual de demonstração: o pack passou a ser colecionado como peça, além de produto. (Dado ilustrativo.)",
		story: "VELA trata a embalagem como escultura doméstica. A marca quase não se anuncia — ela se apoia na mesa e espera ser descoberta. Uma identidade que cheira a linho e vento."
	},
	{
		slug: "aura",
		name: "AURA",
		year: "2025",
		category: "Experiência digital",
		summary: "Uma interface que se sente mais como atmosfera do que como tela.",
		image: "/images/aura.jpg",
		imageWidth: 1792,
		imageHeight: 1008,
		layout: "wide",
		challenge: "Projetar um produto digital fictício sem a gramática usual de cards, menus e dashboards.",
		solution: "Partículas, transparência e um ritmo de respiração. A navegação acontece por gravidade, não por hierarquia de botões.",
		result: "Resultado conceitual de demonstração: usuários de teste descreveram a interface como um ambiente. (Dado ilustrativo.)",
		story: "AURA é um manifesto contra a tela cheia. Luz, intervalo e matéria translúcida. O trabalho pergunta se uma experiência digital pode ser sentida antes de ser usada."
	},
	{
		slug: "frame",
		name: "FRAME",
		year: "2022",
		category: "Campanha visual",
		summary: "Uma campanha sobre o ato de olhar — e o que permanece no recorte.",
		image: "/images/frame.jpg",
		imageWidth: 1728,
		imageHeight: 1152,
		layout: "feature",
		challenge: "Lançar uma série fictícia de fotografia contemporânea sem parecer uma galeria convencional.",
		solution: "Molduras como personagens. Luz de fim de tarde, poeira, sequência. A campanha é um ensaio sobre o enquadramento.",
		result: "Resultado conceitual de demonstração: a imagem da galeria se tornou o cartaz da temporada. (Dado ilustrativo.)",
		story: "FRAME devolve a câmera para o público. Cada quadro é um convite a permanecer. A direção de arte trata a exposição como um filme parado — um corte atrás do outro."
	}
];
var FEATURED = {
	title: "Projeto em destaque",
	name: "ORBIT",
	headline: "ORBIT — Beyond the ordinary.",
	image: "/images/orbit-featured.jpg",
	imageWidth: 1792,
	imageHeight: 1008,
	description: "Uma identidade pensada como campo gravitacional. ORBIT não começa no logotipo — começa no intervalo entre os anéis, no cobre sobre o papel escuro, na maneira como a luz atravessa uma instalação."
};
var ABOUT = {
	title: "Por trás do trabalho.",
	lead: "Rafael Monteiro é um personagem fictício criado para este modelo demonstrativo da NexaWeb. O ateliê, os clientes e os projetos não existem fora desta página.",
	body: [
		"O trabalho habita o espaço entre identidade visual, direção criativa e design digital. Marcas, campanhas e experiências são tratadas como um único ensaio: o que se vê, o que se toca, o que se lembra.",
		"A prática começa no papel e termina no ambiente. Sistemas de identidade, direção de arte, embalagem, interfaces e filmes de marca — sempre com a mesma pergunta: esta imagem merece permanecer?",
		"Nada aqui é um serviço de prateleira. Cada projeto fictício deste portfólio existe para mostrar um ponto de vista: editorial, assimétrico, paciente."
	],
	portrait: "/images/portrait.jpg",
	atelier: "/images/atelier.jpg"
};
var EXPERIENCE = [
	{
		year: "2019",
		title: "Início da carreira criativa",
		text: "Primeiros ensaios de identidade e direção de arte. Um começo fictício, desenhado para este modelo."
	},
	{
		year: "2021",
		title: "Direção de projetos de branding",
		text: "Sistemas visuais para marcas inventadas — da nomenclatura ao material impresso."
	},
	{
		year: "2023",
		title: "Projetos digitais e experiências",
		text: "A prática se abre para interfaces, atmosferas e narrativas em tela."
	},
	{
		year: "2025",
		title: "Direção criativa independente",
		text: "Um ateliê autoral (fictício) para identidades, campanhas e direção de arte."
	}
];
var SPECIALTIES = [
	{
		name: "Branding",
		text: "Sistemas de marca que se sustentam no silêncio, não no excesso."
	},
	{
		name: "Direção de arte",
		text: "Imagem, matéria e ritmo a serviço de um ponto de vista."
	},
	{
		name: "Design digital",
		text: "Interfaces tratadas como espaços, não como painéis."
	},
	{
		name: "Identidade visual",
		text: "Alfabetos, cores e gestos que uma marca pode habitar."
	},
	{
		name: "Experiência de marca",
		text: "O intervalo entre o primeiro olhar e a lembrança."
	},
	{
		name: "Campanhas",
		text: "Ensaios visuais com começo, corte e permanência."
	}
];
var PROJECT_TYPES = [
	"Identidade visual",
	"Experiência digital",
	"Campanha",
	"Direção criativa",
	"Embalagem",
	"Outro"
];
var FAQ = [
	{
		q: "Que tipo de projeto você desenvolve?",
		a: "Neste modelo demonstrativo, o ateliê fictício trabalha identidade visual, direção de arte, design digital, embalagem e campanhas. Nada disso é uma oferta real de serviço."
	},
	{
		q: "Você trabalha com marcas novas?",
		a: "Sim — no universo desta demonstração, marcas em formação são o ponto de partida preferido. Em um ateliê real, isso dependeria de conversa, timing e recorte."
	},
	{
		q: "Como funciona o processo?",
		a: "Um processo ilustrativo: escuta, ensaio, sistema, direção. Pesquisa e referências, depois forma. Este site não representa um fluxo comercial verdadeiro."
	},
	{
		q: "Quanto tempo leva um projeto?",
		a: "Em um cenário fictício, identidades levam algumas semanas a alguns meses. Prazos reais dependem de escopo — e não são cotados aqui."
	},
	{
		q: "Como solicitar um orçamento?",
		a: "Use o formulário desta página. Ele apenas demonstra o envio visualmente: nenhuma mensagem é armazenada ou encaminhada. Este é um modelo da NexaWeb."
	}
];
function getProject(slug) {
	return PROJECTS.find((p) => p.slug === slug);
}
function getNextProject(slug) {
	const i = PROJECTS.findIndex((p) => p.slug === slug);
	if (i < 0) return PROJECTS[0];
	return PROJECTS[(i + 1) % PROJECTS.length];
}
//#endregion
export { NAV as a, SITE as c, getProject as d, FEATURED as i, SPECIALTIES as l, EXPERIENCE as n, PROJECTS as o, FAQ as r, PROJECT_TYPES as s, ABOUT as t, getNextProject as u };
