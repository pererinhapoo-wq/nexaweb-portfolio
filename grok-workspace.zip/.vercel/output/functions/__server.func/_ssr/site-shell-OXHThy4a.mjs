import { i as __toESM } from "../_runtime.mjs";
import { a as NAV, c as SITE } from "./site-vRvvv435.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, p as useLocation, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-shell-OXHThy4a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function scrollToId(id) {
	const el = document.getElementById(id);
	if (!el) return;
	el.scrollIntoView({
		behavior: "smooth",
		block: "start"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function SiteNav() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const location = useLocation();
	const navigate = useNavigate();
	const onHome = location.pathname === "/";
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	function go(id) {
		setOpen(false);
		document.body.style.overflow = "";
		if (onHome) {
			window.history.replaceState(null, "", `/#${id}`);
			window.setTimeout(() => scrollToId(id), 60);
			return;
		}
		navigate({
			to: "/",
			hash: id
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: cn("fixed inset-x-0 top-0 z-40 transition-[background-color,border-color] duration-300", scrolled || open ? "border-b border-line bg-paper/90 backdrop-blur-md" : "border-b border-transparent bg-transparent"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-[92rem] items-center justify-between gap-4 px-5 sm:h-[4.5rem] sm:px-8 lg:px-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "font-display text-xl tracking-tight italic sm:text-2xl",
					onClick: () => setOpen(false),
					children: "RM"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 lg:flex",
					"aria-label": "Principal",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(item.id),
						className: "meta text-mute transition-colors duration-200 hover:text-ink",
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go("contato"),
						className: "meta hidden text-ink link-underline sm:inline-flex",
						children: "Vamos conversar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "meta inline-flex min-h-11 items-center text-ink lg:hidden",
						"aria-expanded": open,
						"aria-controls": "menu-overlay",
						onClick: () => setOpen((v) => !v),
						children: open ? "Fechar" : "Menu"
					})]
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "menu-overlay",
		"aria-hidden": !open,
		inert: !open,
		className: cn("fixed inset-0 z-30 flex flex-col justify-end bg-paper px-6 pb-10 pt-24 transition-[opacity,visibility] duration-300 lg:hidden", open ? "visible opacity-100 pointer-events-auto" : "invisible pointer-events-none opacity-0"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "flex flex-col",
			"aria-label": "Mobile",
			children: [NAV.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => go(item.id),
				className: "flex min-h-16 items-center justify-between border-t border-line text-left",
				style: { transitionDelay: open ? `${i * 40}ms` : "0ms" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-4xl italic tracking-tight sm:text-5xl",
					children: item.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "meta text-faint",
					children: ["0", i + 1]
				})]
			}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => go("contato"),
				className: "mt-8 self-start btn-ink",
				children: "Vamos conversar"
			})]
		})
	})] });
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-line bg-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-[92rem] flex-col gap-10 px-5 py-14 sm:px-8 lg:flex-row lg:items-end lg:justify-between lg:px-12 lg:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl tracking-tight italic sm:text-6xl",
				children: SITE.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-mute",
				children: SITE.role
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-sm text-sm leading-relaxed text-mute",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 — Projeto demonstrativo criado pela NexaWeb." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 italic",
					children: SITE.demoNote
				})]
			})]
		})
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-clip bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#conteudo",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-ink focus:px-4 focus:py-2 focus:text-cream",
				children: "Ir ao conteúdo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "conteudo",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { cn as n, scrollToId as r, SiteShell as t };
